<x-app-layout>
  <x-slot name="header">
      <h2 class="font-semibold text-xl text-gray-800 leading-tight">
        <title> Autofixx Car Care Center | Contact Us </title>
          {{ __('Contact Us') }}
      </h2>
  </x-slot>

  <script src="https://cdn.tailwindcss.com"></script>
@vite('resources/css/app.css')

<body >
  <div class="min-h-screen ">


  
  </div>
</body>
      
         
             
         
</x-app-layout>

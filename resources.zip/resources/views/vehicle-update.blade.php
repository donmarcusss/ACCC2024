<x-app-layout>
    <x-slot name="header">
        <title> Autofixx Car Care Center | Vehicle Update </title>
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            {{ __('Toyota Fortuner') }}
        </h2>
    </x-slot>

    <script src="https://cdn.tailwindcss.com"></script>
@vite('resources/css/app.css')

<body>
    <br>
    <div class="min-h-screen ">

        

    {{-- <div class="m-auto w-6/12 flex items-start gap-4 rounded-lg bg-white p-6 shadow-[0px_14px_34px_0px_rgba(0,0,0,0.08)] ring-1 ring-white/[0.05] transition duration-300 hover:text-black/70 hover:ring-black/20 focus:outline-none focus-visible:ring-[#FF2D20] lg:pb-10" style="margin: auto;"> --}}
       
        

<div class="w-9/12 relative overflow-x-auto shadow-md sm:rounded-lg m-auto ">
    <table class="w-full text-sm text-left rtl:text-right text-gray-500 dark:text-gray-400">
        <thead class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
            <tr>
        
            
            <tr>
                <th scope="col" class="px-6 py-3">
                    Equipment
                </th>
                <th scope="col" class="px-6 py-3">
                    Equipment Price
                </th>
                <th scope="col" class="px-6 py-3">
                    Service
                </th>
                <th scope="col" class="px-6 py-3">
                    Service Price
                </th>
                <th scope="col" class="px-6 py-3">
                    Note
                </th>
                <th scope="col" class="px-6 py-3">
                    Status
                </th>
                <th scope="col" class="px-6 py-3">
                    Total
                </th>
            </tr>
        </thead>
        <tbody>
            {{-- @foreach ($tasks as $task)
            <tr class="odd:bg-white odd:dark:bg-gray-900 even:bg-gray-50 even:dark:bg-gray-800 border-b dark:border-gray-700">
                <td>
                    <div class="form-group">
                        
                        <p>{{ $task->service_name }}</p>
                    </div>
                </td>
        
                <td>
                    <div class="form-group">
                        
                        <p>{{ $task->service_price }}</p>
                    </div>
                </td>
        
                <td>
                    <div class="form-group">
                        
                        <p>{{ $task->equipment_name }}</p>
                    </div>
                </td>
        
                <td>
                    <div class="form-group">
                      
                        <p>{{ $task->equipment_price }}</p>
                    </div>
                </td>
        
                <td>
                    <div class="form-group">
                        
                        <p>{{ $task->note }}</p>
                    </div>
                </td>

                <td>
                    <div class="form-group">
                        
                        <p>{{ $task->equipment_price }} + {{ $task->service_price }}</p>
                    </div>
                </td>

                <td>
                    <div class="form-group">
                        
                        <p>{{ $task->status }}</p>
                    </div>
                </td>
            </tr>
            @endforeach --}}
        </tbody>
        
            
                
        
                         {{-- <td class="px-6 py-4">
                            Total: 5,898.00
                         </td> --}}

                



        </tbody>
    </table>
</div>

                 
               
    </div>
</div>

    </body>
       
</body>
        
           
               
           
</x-app-layout>

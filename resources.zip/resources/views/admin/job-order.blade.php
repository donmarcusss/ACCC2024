@extends('layouts.auth')

<head>
    <title> Autofixx Car Care Center | Job Order</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/flowbite/2.3.0/flowbite.min.css" rel="stylesheet" />
  </head>
  <style>
    .status-pending {
     color: yellow;
     text-transform: uppercase;
     font-weight: bold;
 }
 
 .status-approved {
     color: green;
     text-transform: uppercase;
     font-weight: bold;
 }
 
 .status-cancelled {
   color: red;
   text-transform: uppercase;
   font-weight: bold;
 }
 </style>

@section('content')
<div class="content-wrapper">
    
<div class="card shadow-lg">
    
    <div class="card-body">
        
        <h4 class="card-title">LIST OF JOB ORDERS</h4>
        
        <BR>
        <div class="table-responsive">
          <table class="table">
            <div class="col-12 grid-margin stretch-card">


                



              <button data-modal-target="default-modal" data-modal-toggle="default-modal" class="nav-link btn btn-success create-new-button" id="createbuttonDropdown" data-bs-toggle="dropdown" aria-expanded="false" href="forms">+ Create a new Job Order</button>
</button>
<br>
<script src="https://cdnjs.cloudflare.com/ajax/libs/flowbite/2.3.0/flowbite.min.js"></script>
<!-- Main modal -->
<div id="default-modal" tabindex="-1" aria-hidden="true" class="hidden overflow-y-auto overflow-x-hidden fixed top-0 right-0 left-0 z-50 justify-center items-center w-full md:inset-0 h-[calc(100%-1rem)] max-h-full">
    <div class="relative p-4 w-full max-w-2xl max-h-full">
        <!-- Modal content -->
        <div class="relative bg-white rounded-lg shadow dark:bg-gray-700">
          
            <!-- Modal header -->
            
           
            <div class="flex items-center justify-between p-4 md:p-5 border-b rounded-t dark:border-gray-600">
                <h3 class="text-xl font-semibold text-gray-900 dark:text-white">
                    Create a New Job Order
                </h3>
                <button type="button" class="text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm w-8 h-8 ms-auto inline-flex justify-center items-center dark:hover:bg-gray-600 dark:hover:text-white" data-modal-hide="default-modal">
                    <svg class="w-3 h-3" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 14 14">
                        <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m1 1 6 6m0 0 6 6M7 7l6-6M7 7l-6 6"/>
                    </svg>
                    <span class="sr-only">Close modal</span>
                </button>
            </div>


            
            <!-- Modal body -->
            <div class="p-4 md:p-5 space-y-4">
                
              <form action="{{ route('admin/job-order/save') }}" method="POST" class="space-y-4 md:space-y-6" >
                @csrf

                
                {{-- <div>
                  <label for="user_id" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">User ID</label>
                  <input type="text" name="user_id" id="user_id" class="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" placeholder="" required="">
              </div> --}}

             

              <label for="booking_id" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Select Appointment</label>
<select name="booking_id" id="booking_id" required class="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500">
    <option value="">Choose an appointment</option>
    @foreach($appointments as $appointment)
        @if($appointment->status === 'approved') <!-- Only include pending status -->
            <option value="{{ $appointment->id }}"> 
                {{ $appointment->formatted_id }} - {{ $appointment->first_name }} {{ $appointment->last_name }} - {{ $appointment->vehicle_manufacturer }} {{ $appointment->vehicle_model }}
            </option>
        @endif
    @endforeach
</select>

            {{-- <div>
              <label for="vehicle_manufacturer" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Vehicle Manufacturer</label>
              <input list="manufacturers" name="vehicle_manufacturer" id="vehicle_manufacturer" class="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" placeholder="Choose or type" required="">
              
              <datalist id="manufacturers">
                  <option value="Isuzu">
                  <option value="Hyundai">
                  <option value="Foton">
                  <option value="Fuso">
                  <option value="Dongfeng">
                  <option value="Hino">
                  <option value="TATA">
                  <option value="HOWO">
                  <option value="FAW">
                  <option value="UD Trucks">
                  <option value="JMC">
                  <option value="Shacman">
                  <option value="IVECO">
                  <option value="T-King">
                  <option value="Mazda">
                  <option value="Toyota">
                  <option value="Honda">
                  <option value="Mitsubishi">
                  <option value="Suzuki">
                  <option value="Nissan">
                  <option value="Kia">
                  <option value="Cherry">
                  <option value="MG">
              </datalist>
          </div>
          
          <div>
              <label for="vehicle_type" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Vehicle Type</label>
              <input list="vehicle_types" name="vehicle_type" id="vehicle_type" class="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" placeholder="Choose or type" required="">
              
              <datalist id="vehicle_types">
                  
                      <option value="Sedan">
                      <option value="Hatchbacks">
                      <option value="Coupes">
                      <option value="Subcompacts">
                      <option value="SUV">
                      <option value="Pickup Truck">
                      <option value="Van">
                      <option value="MPV">
                      <option value="Truck">
                      <option value="6 Wheeler Truck">
                
              </datalist>
              
              <div id="vehicle_type_error" class="mt-2 text-sm text-red-600" style="display: none;">
                  Please select a vehicle type from the list or enter another value.
              </div>
          </div>
          
          <div>
              <label for="vehicle_model" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Vehicle Model</label>
              <input list="vehicle_models" name="vehicle_model" id="vehicle_model" class="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" placeholder="" required="">
              
              <datalist id="vehicle_models"></datalist>
          </div>
          
          <script>
              const vehicleData = {
                  "Isuzu": {
                      types: ["SUV", "Pickup Truck", "Van", "Truck", "6 Wheeler Truck"],
                      models: {
                          "SUV": ["mu-X"],
                          "Pickup Truck": ["Isuzu D-Max"],
                          "Van": ["Isuzu Traviz"],
                          "Truck": ["Isuzu N-Series", "Isuzu F-Series"],
                          "6 Wheeler Truck": ["Isuzu N-Series"]
                      }
                  },
                  "Hyundai": {
                      types: ["Sedan", "Hatchbacks", "Subcompacts", "SUV", "Pickup Truck", "Van", "MPV", "Truck", "6 Wheeler Truck"],
                      models: {
                          "Sedan": ["Hyundai Accent", " Elantra"],
                          "Hatchbacks": [" i20"],
                          "Subcompacts": [" Reina"],
                          "SUV": [" Tucson", " Santa Fe"],
                          "Pickup Truck": [" H-100"],
                          "Van": [" Starex"],
                          "MPV": [" KONA"],
                          "Truck": [" HD Series"],
                          "6 Wheeler Truck": [" HD50S"]
                      }
                  },
                  "Foton": {
                      types: ["SUV", "Pickup Truck", "Van", "Truck", "6 Wheeler Truck"],
                      models: {
                          "SUV": [" Toplander"],
                          "Pickup Truck": [" Thunder"],
                          "Van": [" View"],
                          "Truck": [" Auman"],
                          "6 Wheeler Truck": [" Auman C Series"]
                      }
                  },
                  "Fuso": {
                      types: ["Truck", "6 Wheeler Truck"],
                      models: {
                          "Truck": [" Canter"],
                          "6 Wheeler Truck": [" Canter"]
                      }
                  },
                  "Dongfeng": {
                      types: ["SUV", "Pickup Truck", "Van", "Truck", "6 Wheeler Truck"],
                      models: {
                          "SUV": [" Ax7"],
                          "Pickup Truck": [" Rich"],
                          "Van": [" KX"],
                          "Truck": [" Tianjin"],
                          "6 Wheeler Truck": [" C-Series"]
                      }
                  },
                  "Hino": {
                      types: ["Truck", "6 Wheeler Truck"],
                      models: {
                          "Truck": [" 300 Series"],
                          "6 Wheeler Truck": [" 500 Series"]
                      }
                  },
                  "TATA": {
                      types: ["SUV", "Pickup Truck", "Van", "MPV", "Truck", "6 Wheeler Truck"],
                      models: {
                          "SUV": [" Harrier"],
                          "Pickup Truck": [" Yodha"],
                          "Van": [" Winger"],
                          "MPV": [" Hexa"],
                          "Truck": [" LPT Series"],
                          "6 Wheeler Truck": [" LPK Series"]
                      }
                  },
                  "HOWO": {
                      types: ["Truck", "6 Wheeler Truck"],
                      models: {
                          "Truck": [" Truck Series"],
                          "6 Wheeler Truck": [" A7"]
                      }
                  },
                  "FAW": {
                      types: ["SUV", "Pickup Truck", "Truck", "6 Wheeler Truck"],
                      models: {
                          "SUV": [" Bestune T77"],
                          "Pickup Truck": [" J6"],
                          "Truck": [" 4X2", " 6X4 Series"],
                          "6 Wheeler Truck": [" J6P"]
                      }
                  },
                  "UD Trucks": {
                      types: ["Truck", "6 Wheeler Truck"],
                      models: {
                          "Truck": [" Quon"],
                          "6 Wheeler Truck": [" Croner"]
                      }
                  },
                  "JMC": {
                      types: ["SUV", "Pickup Truck", "Van", "Truck", "6 Wheeler Truck"],
                      models: {
                          "SUV": [" Yuhu"],
                          "Pickup Truck": [" Baodian"],
                          "Van": [" Vigus"],
                          "Truck": [" 4X2", " 6X4 Series"],
                          "6 Wheeler Truck": [" 6T"]
                      }
                  },
                  "Shacman": {
                      types: ["Truck", "6 Wheeler Truck"],
                      models: {
                          "Truck": [" X3000"],
                          "6 Wheeler Truck": [" F3000"]
                      }
                  },
                  "IVECO": {
                      types: ["Van", "MPV", "Truck", "6 Wheeler Truck"],
                      models: {
                          "Van": [" Daily"],
                          
                          "Truck": [" Stralis"],
                          "6 Wheeler Truck": [" Eurocargo"]
                      }
                  },
                  "T-King": {
                      types: ["Pickup Truck", "Van", "Truck", "6 Wheeler Truck"],
                      models: {
                          "Pickup Truck": ["None"],
                          "Van": [" Light Van"],
                          "Truck": [" Mini Truck"],
                          "6 Wheeler Truck": [" 6T"]
                      }
                  },
                  "Mazda": {
                      types: ["Sedan", "Hatchbacks", "Coupes", "SUV", "Pickup Truck"],
                      models: {
                          "Sedan": [" 2", " 3"],
                          "Hatchbacks": [" 2 Hatchback", " 3 Hatchback"],
                          "Coupes": [" MX-5 Miata"],
                          "SUV": [" CX-30", " CX-5", " CX-9"],
                          "Pickup Truck": [" BT-50"]
                      }
                  },
                  "Toyota": {
                      types: ["Sedan", "Hatchbacks", "SUV", "Pickup Truck", "Van", "MPV", "Truck", "6 Wheeler Truck"],
                      models: {
                          "Sedan": [" Vios", " Corolla Altis"],
                          "Hatchbacks": [" Yaris"],
                          "SUV": [" Fortuner", " RAV4"],
                          "Pickup Truck": [" Hilux"],
                          "Van": [" Hiace"],
                          "MPV": [" Innova"],
                          "Truck": [" Dyna"],
                          "6 Wheeler Truck": [" Dyna"]
                      }
                  },
                  "Honda": {
                      types: ["Sedan", "Hatchbacks", "SUV"],
                      models: {
                          "Sedan": [" City", " Civic"],
                          "Hatchbacks": ["Hnda Jazz"],
                          "SUV": [" CR-V"]
                      }
                  },
                  "Mitsubishi": {
                      types: ["Sedan", "Hatchbacks", "SUV", "Pickup Truck", "Van"],
                      models: {
                          "Sedan": [" Mirage G4"],
                          "Hatchbacks": [" Mirage"],
                          "SUV": [" Montero Sport", " Xpander"],
                          "Pickup Truck": [" L200"],
                          "Van": [" L300"]
                      }
                  },
                  "Suzuki": {
                      types: ["Sedan", "Hatchbacks", "Subcompacts", "SUV"],
                      models: {
                          "Sedan": [" Dzire"],
                          "Hatchbacks": [" Swift"],
                      
                          "SUV": [" Vitara"]
                      }
                  },
                  "Nissan": {
                      types: ["Sedan", "SUV", "Pickup Truck", "Truck"],
                      models: {
                          "Sedan": [" Almera"],
                          "SUV": [" Terra"],
                          "Pickup Truck": [" Navara"],
                          "Truck": [" Diesel"]
                      }
                  },
                  "Kia": {
                      types: ["Sedan", "SUV"],
                      models: {
                          "Sedan": [" Soluto"],
                          "SUV": [" Seltos"]
                      }
                  },
                  "Cherry": {
                      types: ["Sedan", "Subcompacts", "SUV", "Pickup Truck", "Van"],
                      models: {
                          "Sedan": [" QQ", " Emgrand"],
                          "Subcompacts": [" Tiggo 2"],
                          "SUV": [" Tiggo 5", " Tiggo 7"],
                          "Pickup Truck": [" Tigo"],
                          "Van": [" Van"]
                      }
                  },
                  "MG (Morris Garages)": {
                      types: ["Sedan", "Hatchbacks", "SUV", "Pickup Truck"],
                      models: {
                          "Sedan": [" 6"],
                          "Hatchbacks": [" 3"],
                          "SUV": [" ZS", " RX5"],
                          "Pickup Truck": [" T60"]
                      }
                  }
              };

          
              document.getElementById('vehicle_manufacturer').addEventListener('change', function() {
                  const manufacturer = this.value;
                  const typesInput = document.getElementById('vehicle_types');
                  const modelsInput = document.getElementById('vehicle_models');
          
                  // Clear previous options
                  typesInput.innerHTML = '';
                  modelsInput.innerHTML = '';
          
                  console.log(`Selected Manufacturer: ${manufacturer}`);  // Debugging log
          
                  if (vehicleData[manufacturer]) {
                      vehicleData[manufacturer].types.forEach(type => {
                          typesInput.innerHTML += `<option value="${type}">`;
                      });
                      console.log(`Available Types: ${vehicleData[manufacturer].types}`); // Debugging log
                  } else {
                      console.log("No data found for the selected manufacturer."); // Debugging log
                  }
              });
          
              document.getElementById('vehicle_type').addEventListener('change', function() {
                  const manufacturer = document.getElementById('vehicle_manufacturer').value;
                  const selectedType = this.value;
                  const modelsInput = document.getElementById('vehicle_models');
                  
                  // Clear previous models
                  modelsInput.innerHTML = '';
          
                  console.log(`Selected Type: ${selectedType}`);  // Debugging log
          
                  if (vehicleData[manufacturer]?.models[selectedType]) {
                      vehicleData[manufacturer].models[selectedType].forEach(model => {
                          modelsInput.innerHTML += `<option value="${model}">`;
                      });
                      console.log(`Available Models: ${vehicleData[manufacturer].models[selectedType]}`); // Debugging log
                  } else {
                      console.log("No models found for the selected type."); // Debugging log
                  }
              });
          </script>
          
              
          
          <div>
              <label for="description" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Short description about the problem</label>
              <input type="text" name="description" id="description" class="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" placeholder="" required="">
          </div> --}}

          {{-- <div>
              <label for="booking_date" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Date</label>
              <input 
                  type="datetime-local" 
                  id="booking_date" 
                  name="booking_date" 
                  min="{{ \Carbon\Carbon::now()->format('Y-m-d') }}T09:00" 
                  class="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                  required=""
              >
          
              <!-- Error message container -->
              <div id="booking_date_error" class="mt-2 text-sm text-red-600" style="display: none;">
                  You can only choose a time between 9 AM and 5 PM.
              </div>
          </div>
          
          <script>
              document.getElementById('booking_date').addEventListener('change', function() {
                  const bookingDate = new Date(this.value);
                  const hours = bookingDate.getHours();
                  const errorElement = document.getElementById('booking_date_error');
                  
                  // Check if the time is outside of 9 AM to 5 PM
                  if (hours < 9 || hours >= 17) {
                      errorElement.style.display = 'block'; // Show the error message
                      this.value = ''; // Clear the invalid input
                  } else {
                      errorElement.style.display = 'none'; // Hide the error message if valid
                  }
              });
          </script> --}}

            {{-- <div>
              <label for="description" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Description</label>
              <input type="text" name="description" id="description" class="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" placeholder="" required="">
          </div> --}}

          
        

      

      <div>
        <label for="status" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Status</label>
        <select  name="status" class="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" placeholder="TOYOTA" required="">
            <option value="pending"> pending  </option>
            <option value="approved"> approved </option>
            <option value="cancelled">cancelled </option>
          </select>
    </div>
  
            <!-- Modal footer -->
            <div class="flex items-center p-4 md:p-5 border-t border-gray-200 rounded-b dark:border-gray-600">
              <button data-modal-hide="default-modal" type="submit" class="text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800">Save</button>
              <button data-modal-hide="default-modal" type="button" class="py-2.5 px-5 ms-3 text-sm font-medium text-gray-900 focus:outline-none bg-white rounded-lg border border-gray-200 hover:bg-gray-100 hover:text-blue-700 focus:z-10 focus:ring-4 focus:ring-gray-100 dark:focus:ring-gray-700 dark:bg-gray-800 dark:text-gray-400 dark:border-gray-600 dark:hover:text-white dark:hover:bg-gray-700">Cancel</button>
          </div>
      </div>

       
  
                  
                
        </form>



            </div>
         
                
                        
            
            <thead>
              
                <th>Link</th>
                <th> Name </th>
                <th> Vehicle </th>
                <th> Status </th>
                <th> Date </th>
                <th> Status </th>
                <th> Action </th>
                
              
            </thead>


            
                <tbody>
                  
                    <tr>
                      @foreach ($job_orders as $job_order)
    @if (is_null($job_order->booking_id))
        <tr>
            <td colspan="5">No booking ID available for this job order.</td>
        </tr>
    @else
        <tr>
          <td>{{ $job_order->booking->formatted_id }}</td>
            <td>
                <a href="{{ route('admin/job-order/task', ['job_order_id' => $job_order->id]) }}" class="btn btn-info btn-icon-text">Job Order <i class="badge badge-info"></i></a>
            </td>
            
            <td>{{ optional($job_order->booking->user)->first_name }} {{ optional($job_order->booking->user)->last_name }}</td>
            <td>
                {{ $job_order->booking->vehicle_manufacturer }} {{ $job_order->booking->vehicle_model }} {{ $job_order->booking->vehicle_type }}
            </td>
            <td>{{ $job_order->created_at}}</td>
            <td>{{ $job_order->status}}</td>
            <td>
                <a class="btn btn-warning" href="{{ route('admin/job-order/edit', ['id' => $job_order->id]) }}">Edit</a>
                <a type="button" class="btn btn-danger" href="{{ route('admin/job-order/delete', ['id' => $job_order->id]) }}">Delete</a>
            </td>
        </tr>
    @endif
@endforeach



                    
                      
                      
                     {{-- <td>{{ $job_order->booking->user->name }}</td> --}}
                      
                      
                      {{-- <td>{{ \Carbon\Carbon::parse($job_order->date_created_at)->format('F-d-Y') }}</td>
                      <td> {{ $job_order->description }}  </td>
                      <td>
                        <span aria-expanded="false" role="button" tabindex="0" 
        class="{{ $job_order->status == 'pending' ? 'status-pending' : ($job_order->status == 'approved' ? 'status-approved' : ($job_order->status == 'cancelled' ? 'status-cancelled' : '')) }}">
        {{ ucfirst($job_order->status) }} <!-- Capitalizes the first letter -->
    </span>
                    </td> 
                    
                     
                      
                      
                      
                      
                    
                      
                    
                    
                    {{-- <td>
                       <a  class="btn btn-warning "  aria-expanded="false" href="{{ route('admin/appointments/edit', ['id'=>$booking->id]) }}">Edit</a>  
                       <a type="button" class="btn btn-danger " href="{{ route('admin/appointments/delete', ['id'=>$booking->id]) }}  aria-expanded="false">Delete</a>
                    </td> --}}
                    
                    
                   
                   
              
                  </tr>  
                 
                 
    
    
    
                  
                </tbody>
          </table>
        </div>
      </div>
    </div>
    </div>
    @endsection




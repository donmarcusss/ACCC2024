@extends('layouts.auth')

<head>
  <title> Autofixx Car Care Center | Schedule</title>
</head>

@section('content')
<div class="content-wrapper">
<div class="card shadow-lg">
    <div class="card-body">
        <h4 class="card-title">Edit</h4>
        <BR>
        

           
            
            <form action="{{route('admin/job-order/update', $task->id )}}" method="POST" class="space-y-4 md:space-y-6" >
                @csrf
                @method('PUT')
            
                <div class="form-group">
                  <label for="status">Status</label>
                  <select name="status" id="status" class="form-control" required style="color: white;">
                      <option value="">Select Status</option>
                      <option value="pending" {{ old('status', $task->status) == 'pending' ? 'selected' : '' }} >PENDING</option>
                      <option value="approved" {{ old('status', $task->status) == 'on-going' ? 'selected' : '' }}>ON-GOING</option>
                      <option value="cancelled" {{ old('status', $task->status) == 'finished' ? 'selected' : '' }}>FINISHED</option>
                      <option value="cancelled" {{ old('status', $task->status) == 'canceled' ? 'selected' : '' }}>CANCELLED</option>
                  </select>
              </div>


                <script>
                    document.getElementById('booking_date').addEventListener('input', function (e) {
                        const input = e.target;
                        const selectedDate = new Date(input.value);
                        const selectedHours = selectedDate.getUTCHours();
                        
                        // Check if the time is outside 9 AM to 5 PM
                        if (selectedHours < 9 || selectedHours >= 17) {
                            alert('Please select a time between 9 AM and 5 PM.');
                            input.value = ''; // Clear the input
                        }
                    });
                </script>
                

                  <button type="submit" class="btn btn-warning "  aria-expanded="false">Update</button>
                
               
              </form>




        
      </div>
    </div>
    </div>
    @endsection



                
                
                
                
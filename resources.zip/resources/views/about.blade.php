<x-app-layout>
    <x-slot name="header">
        <title> Autofixx Car Care Center | About </title>
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            {{ __('About Us') }}
        </h2>
    </x-slot>

    <script src="https://cdn.tailwindcss.com"></script>
@vite('resources/css/app.css')

<body >
    <div class="min-h-screen ">


    
    </div>
</body>
        
           
               
           
</x-app-layout>

<a class="text-3xl font-bold leading-none w-1/8" href="#">
  <img src="{{asset('/images/autofixx_navbar_logo.png')}}" alt="profile Pic" height="10" width="130" margin="0" padding="0" >
</a>

import './bootstrap';

import.meta.glob([
    '../assets/images/**',
    '../assetsfonts/**',
  ]);
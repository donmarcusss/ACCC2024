
const myModal = new bootstrap.Modal('#exampleModalCenter');


myModal.show();
